READ ME!

System Requirements: 

OS: Windows 10 SP1 or higher
Processor: Pentium 4 G1 (or equivalent) or later (64-bit)
RAM: 256 MB
Screen Resolution: 1024x768
DiskSpace: 620 MB

For Report generation: Microsoft Excel

First Installation Steps:

1. Install LabVIEW Runtime, ver. 2018 SP 1
	(https://www.ni.com/en-us/support/downloads/software-products/download.labview-runtime.html#309628)

2. Place unzipped "LC-and-LD-Expression-Calc" in desired directory

3. Run "Lc-Ld_Expression-Calc_ver1.0.exe" (You may wish to create a shortcut for the executable file.)

4. Explore program with TestData.

5. Enjoy!